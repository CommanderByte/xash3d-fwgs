# Phase Validation Report

- Timestamp: 2026-05-10 23:18:33
- Status: PASS
- Repo: C:\git\xash3d-fwgs
- Runtime: C:\git\xash3d-fwgs\run-win32
- XASH3D_BASEDIR: C:\git\xash3d-fwgs\run-win32
- XASH3D_RODIR: C:\Program Files (x86)\Steam\steamapps\common\Half-Life

## Steps

- PASS Focused test target (2.032s)
  - tests passed 1/1
- PASS Build xash (2.007s)
  - xash target built
- PASS Full test suite (5.802s)
  - tests passed 102/102
- PASS Refresh runtime binaries (0.077s)
  - C:\git\xash3d-fwgs\build\engine\xash.dll -> C:\git\xash3d-fwgs\run-win32\xash.dll
C:\git\xash3d-fwgs\build\engine\xash.pdb -> C:\git\xash3d-fwgs\run-win32\xash.pdb
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.dll -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.dll
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.pdb -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.pdb
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.dll -> C:\git\xash3d-fwgs\run-win32\ref_gl.dll
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.pdb -> C:\git\xash3d-fwgs\run-win32\ref_gl.pdb
- PASS Runtime smoke (0.774s)
  - first frame 0.502 seconds; stopped with reason command

## Evidence

Evidence: `.\waf.bat build --targets=test_engine_game_dll_string_pool_compat` passed, `.\waf.bat build --targets=xash` passed, `.\waf.bat build --alltests` tests passed 102/102, `run-win32\xash3d.exe -dev 2 -log +fs_path +wait +wait +quit` reached first frame in 0.502 seconds and stopped with reason `command`.

- Smoke log: C:\git\xash3d-fwgs\run-win32\engine.log
