# Phase Validation Report

- Timestamp: 2026-05-10 20:38:03
- Status: PASS
- Repo: C:\git\xash3d-fwgs
- Runtime: C:\git\xash3d-fwgs\run-win32
- XASH3D_BASEDIR: C:\git\xash3d-fwgs\run-win32
- XASH3D_RODIR: C:\Program Files (x86)\Steam\steamapps\common\Half-Life

## Steps

- PASS Focused test target (1.455s)
  - completed
- PASS Build xash (1.584s)
  - xash target built
- PASS Full test suite (9.196s)
  - tests passed 91/91
- PASS Refresh runtime binaries (0.207s)
  - C:\git\xash3d-fwgs\build\engine\xash.dll -> C:\git\xash3d-fwgs\run-win32\xash.dll
C:\git\xash3d-fwgs\build\engine\xash.pdb -> C:\git\xash3d-fwgs\run-win32\xash.pdb
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.dll -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.dll
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.pdb -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.pdb
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.dll -> C:\git\xash3d-fwgs\run-win32\ref_gl.dll
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.pdb -> C:\git\xash3d-fwgs\run-win32\ref_gl.pdb
- PASS Runtime smoke (2.153s)
  - first frame 1.839 seconds; stopped with reason command

## Evidence

Evidence: `.\waf.bat build --targets=test_engine_server_spawn_handshake` passed, `.\waf.bat build --targets=xash` passed, `.\waf.bat build --alltests` tests passed 91/91, `run-win32\xash3d.exe -dev 2 -log +fs_path +wait +wait +quit` reached first frame in 1.839 seconds and stopped with reason `command`.

- Smoke log: C:\git\xash3d-fwgs\run-win32\engine.log
