# Phase Validation Report

- Timestamp: 2026-05-11 17:17:38
- Status: PASS
- Repo: C:\git\xash3d-fwgs
- Runtime: C:\git\xash3d-fwgs\run-win32
- XASH3D_BASEDIR: C:\git\xash3d-fwgs\run-win32
- XASH3D_RODIR: C:\Program Files (x86)\Steam\steamapps\common\Half-Life

## Steps

- PASS Build xash (2.591s)
  - xash target built
- PASS Full test suite (6.799s)
  - tests passed 141/141
- PASS Refresh runtime binaries (0.058s)
  - C:\git\xash3d-fwgs\build\src\xash3d.exe -> C:\git\xash3d-fwgs\run-win32\xash3d.exe
C:\git\xash3d-fwgs\build\src\xash3d.pdb -> C:\git\xash3d-fwgs\run-win32\xash3d.pdb
C:\git\xash3d-fwgs\build\engine\xash.dll -> C:\git\xash3d-fwgs\run-win32\xash.dll
C:\git\xash3d-fwgs\build\engine\xash.pdb -> C:\git\xash3d-fwgs\run-win32\xash.pdb
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.dll -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.dll
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.pdb -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.pdb
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.dll -> C:\git\xash3d-fwgs\run-win32\ref_gl.dll
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.pdb -> C:\git\xash3d-fwgs\run-win32\ref_gl.pdb
- PASS Runtime smoke (0.88s)
  - first frame 0.508 seconds; stopped with reason command

## Evidence

Evidence: `.\waf.bat build --targets=xash` passed, `.\waf.bat build --alltests` tests passed 141/141, `run-win32\xash3d.exe -dev 2 -log +fs_path +wait +wait +quit` reached first frame in 0.508 seconds and stopped with reason `command`.

- Smoke log: C:\git\xash3d-fwgs\run-win32\engine.log
