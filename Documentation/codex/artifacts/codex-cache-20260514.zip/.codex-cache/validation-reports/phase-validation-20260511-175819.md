# Phase Validation Report

- Timestamp: 2026-05-11 17:58:29
- Status: PASS
- Repo: C:\git\xash3d-fwgs
- Runtime: C:\git\xash3d-fwgs\run-win32
- XASH3D_BASEDIR: C:\git\xash3d-fwgs\run-win32
- XASH3D_RODIR: C:\Program Files (x86)\Steam\steamapps\common\Half-Life

## Steps

- PASS Focused test target (1.631s)
  - completed
- PASS Build xash (1.729s)
  - xash target built
- PASS Full test suite (5.976s)
  - tests passed 132/132
- PASS Refresh runtime binaries (0.082s)
  - C:\git\xash3d-fwgs\build\src\xash3d.exe -> C:\git\xash3d-fwgs\run-win32\xash3d.exe
C:\git\xash3d-fwgs\build\src\xash3d.pdb -> C:\git\xash3d-fwgs\run-win32\xash3d.pdb
C:\git\xash3d-fwgs\build\engine\xash.dll -> C:\git\xash3d-fwgs\run-win32\xash.dll
C:\git\xash3d-fwgs\build\engine\xash.pdb -> C:\git\xash3d-fwgs\run-win32\xash.pdb
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.dll -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.dll
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.pdb -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.pdb
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.dll -> C:\git\xash3d-fwgs\run-win32\ref_gl.dll
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.pdb -> C:\git\xash3d-fwgs\run-win32\ref_gl.pdb
- PASS Runtime smoke (0.852s)
  - first frame 0.540 seconds; stopped with reason command

## Evidence

Evidence: `.\waf.bat build --targets=test_engine_server_runtime_commands,test_engine_server_world_policies,test_engine_server_shared_rules,test_engine_server_query_responses,test_engine_game_dll_user_messages,test_engine_game_dll_bridge_domain` passed, `.\waf.bat build --targets=xash` passed, `.\waf.bat build --alltests` tests passed 132/132, `run-win32\xash3d.exe -dev 2 -log +fs_path +wait +wait +quit` reached first frame in 0.540 seconds and stopped with reason `command`.

- Smoke log: C:\git\xash3d-fwgs\run-win32\engine.log
