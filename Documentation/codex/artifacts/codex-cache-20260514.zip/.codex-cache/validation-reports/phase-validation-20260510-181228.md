# Phase Validation Report

- Timestamp: 2026-05-10 18:12:35
- Status: FAIL
- Repo: C:\git\xash3d-fwgs
- Runtime: C:\git\xash3d-fwgs\run-win32
- XASH3D_BASEDIR: C:\git\xash3d-fwgs\run-win32
- XASH3D_RODIR: C:\Program Files (x86)\Steam\steamapps\common\Half-Life

## Steps

- PASS Focused test target (1.422s)
  - completed
- PASS Build xash (1.594s)
  - xash target built
- PASS Full test suite (2.758s)
  - tests passed 80/80
- PASS Refresh runtime binaries (0.055s)
  - C:\git\xash3d-fwgs\build\src\xash3d.exe -> C:\git\xash3d-fwgs\run-win32\xash3d.exe
C:\git\xash3d-fwgs\build\src\xash3d.pdb -> C:\git\xash3d-fwgs\run-win32\xash3d.pdb
C:\git\xash3d-fwgs\build\engine\xash.dll -> C:\git\xash3d-fwgs\run-win32\xash.dll
C:\git\xash3d-fwgs\build\engine\xash.pdb -> C:\git\xash3d-fwgs\run-win32\xash.pdb
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.dll -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.dll
C:\git\xash3d-fwgs\build\filesystem\filesystem_stdio.pdb -> C:\git\xash3d-fwgs\run-win32\filesystem_stdio.pdb
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.dll -> C:\git\xash3d-fwgs\run-win32\ref_gl.dll
C:\git\xash3d-fwgs\build\ref\gl\ref_gl.pdb -> C:\git\xash3d-fwgs\run-win32\ref_gl.pdb
- FAIL Runtime smoke (0.87s)
  - You cannot call a method on a null-valued expression.

## Evidence

Evidence: `.\waf.bat build --targets=test_engine_server_resource_catalog` passed, `.\waf.bat build --targets=xash` passed, `.\waf.bat build --alltests` tests passed 80/80.

- Smoke log: C:\git\xash3d-fwgs\run-win32\engine.log
