### Phase 76 Sidecar Audit: `SV_BuildSoundMsg` Extraction Boundaries

**Note**: `SV_BuildSoundMsg` is not present in the provided `sv_game.c`. It likely resides in another file (e.g., `sv_send.c`, `sv_msg.c`). This audit assumes standard HL1-style sound message construction and references protocol definitions from `protocol.h`.

---

#### 🔍 **Compatibility-Sensitive Fields & Flags**
From `protocol.h`:
- **Sound command**: `svc_sound` (`6`)
- **Flags** (bitmask in `byte`, per `SND_*` defines):
  - `SND_VOLUME` (1<<0) — *must* be present if volume ≠ default
  - `SND_ATTENUATION` (1<<1)
  - `SND_SEQUENCE` (1<<2) — implies sentence index, not sound index
  - `SND_PITCH` (1<<3)
  - `SND_SENTENCE` (1<<4) — critical: overrides sound index with sentence index
  - `SND_STOP`, `SND_LOCALSOUND`, etc. — may affect client behavior

⚠️ **Compatibility risks**:
- Sending `SND_SENTENCE` + invalid sentence index → undefined client behavior (crash or silence).
- Omitting required flags (`SND_VOLUME`, `SND_PITCH`) when present in message → mismatched playback.
- Using `SND_SEQUENCE` without valid script/sentence data → client may ignore sound.

---

#### 📦 **Command Byte & Extraction Boundaries**
In `svc_sound` message:
1. **Flags** (1 byte)
2. **Sound index / sentence index** (1 byte if < 256, else 2 bytes? — *HL1 uses 8-bit indices*)
3. **Volume** (optional: 1 byte if `SND_VOLUME`)
4. **Attenuation** (optional: 1 byte if `SND_ATTENUATION`)
5. **Pitch** (optional: 1 byte if `SND_PITCH`)
6. **Position/Entity**:
   - If local sound (`SND_LOCALSOUND`): none
   - Else: entity index (byte) + optional origin (3 floats)

✅ **Safe extraction bounds**:
- Minimum message size: **2 bytes** (flags + index)
- Max theoretical size: ~15–18 bytes (with full flags + position)
- Use `MSG_GetNumBitsLeft()` / `MSG_GetNumBytesLeft()` to validate before reading.

---

#### 🚫 **Invalid Sample Behavior**
- **Sound index ≥ MAX_SOUNDS** (`2048`): client may clamp or ignore.
- **Sentence index out of range**: undefined — some clients crash, others skip silently.
- **Missing `SND_VOLUME` but volume field present in buffer**: alignment/parse error → overflow risk.
- **Negative pitch/volume values**: HL1 uses unsigned bytes; signed interpretation causes distortion/crash.

---

#### 🧪 **Focused Tests**
1. **Boundary tests**:
   - Send sound with flags = `0x0F` (all optional fields present) + max index (`255`) → verify no overflow.
   - Send sound with `SND_SENTENCE | SND_SEQUENCE`, invalid sentence ID (`9999`) → check client crash/silence.

2. **Truncation tests**:
   - Truncate message after flags byte (no index) → ensure `MSG_Overflow()` is set and no read past buffer.
   - Omit optional fields but set corresponding flag bits → verify client doesn’t misparse subsequent bytes.

3. **Compatibility tests**:
   - Send sound with `SND_LOCALSOUND` + origin → should be ignored by client (per HL1 spec).
   - Use pitch = `0` or `255` → test edge-case audio behavior.

4. **Buffer overflow tests**:
   - Write 3-byte index where only 1 is expected → verify engine rejects malformed messages before playback.

---

#### 📌 Summary Recommendations
- Validate flag presence *before* reading optional fields.
- Clamp sound/sentence indices to `[0, MAX_SOUNDS)` / `[0, MAX_SENTENCES)`.
- Prefer unsigned byte reads