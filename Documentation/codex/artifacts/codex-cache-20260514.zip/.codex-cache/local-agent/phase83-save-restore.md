### Phase 83 Side Audit: Save/Restore Baseline vs `sv_save.c`

#### ✅ **Confirmed Compatibility**
- **Magic values & versions**: `VALV` (`0x564C4156`) / `JSAV` (`0x5641534A`) and versions `0x71`/`0x67` match docs.
- **File extensions**: `.HL1`, `.HL2`, `.HL3`, `.sav` layout matches.
- **Token table handling**: NUL-padded strings, rebasing `pBaseData` after reading tokens — correctly implemented and documented.

#### ⚠️ **Missing / Incomplete Coverage in Baseline Docs**

| Area | Issue | Recommendation |
|------|-------|----------------|
| **`HL3` entity patch malformed indexes** | `EntityPatchRead()` lacks bounds check on read entity IDs before setting `FENTTABLE_REMOVED`. | Add fixture test with out-of-range index (e.g., `tableCount + 10`) to verify crash or safe skip. |
| **`viewentity` in `.HL2`** | Stored as `char[sizeof(short)]`, not `FIELD_SHORT`. Docs mention HLU SDK quirk but don’t warn about endianness/alignment risk on non-x86. | Add test: write/read `viewentity = 0x1234` and verify byte order matches little-endian assumption. |
| **Lightstyle section** | `lightStyleCount` in header may be > actual lightstyles written if some are empty. Docs don’t clarify whether empty styles (e.g., `""`) are omitted or preserved. | Add fixture: save with 10 lightstyles, verify only non-empty ones appear in stream. |
| **`SAVE_CLIENT.viewentity` packing** | Uses `FIELD_CHARACTER[sizeof(short)]`, but `sizeof(short)` may be 4 on some platforms (e.g., 64-bit). Code assumes 2. | Add compile-time assert: `STATIC_ASSERT(sizeof(short) == 2, "viewentity assumes 16-bit short")`. |
| **`tokenSize` trailing bytes** | Docs note rebased pointer can differ from disk offset; no test for malformed extra NULs or garbage after last token. | Add fixture with `tokenSize = actual + 5`, verify parser stops at correct count and ignores tail. |
| **`mapCount` in `.sav` header** | Used only to loop over bundled files — but if `mapCount > actual HL? files`, extra reads will fail silently (empty filename). | Add fixture: set `mapCount = 3`, include only 2 files; verify no crash, and last file read is skipped. |
| **`gTitleComments[]` ordering** | Docs note “ordering is important” but don’t clarify if early matches short-circuit (yes — `!Q_strnicmp(... len)`). | Add test: map `"C1A0_extra"` should match `"C1A0"` only if prefix, not substring. |
| **`FENTTABLE_REMOVED` flag usage** | Docs mention it’s used for cross-level transitions but don’t clarify whether `HL3` patch is optional or required (it’s optional — fallback to full restore). | Add fixture: missing `.HL3`, verify no crash and entities are restored from `.HL1`. |

#### 🔍 **Ambiguities / Uncertainties**
| Area | Uncertainty | Suggested Test |
|------|-------------|----------------|
| **`SAVEFILE_HEADER` vs `JSAV` in `.sav` outer file** | Baseline says outer `.sav` uses `JSAV`, but code writes `SAVEGAME_HEADER` (`JSAV`) and version `0x71`. Is this intentional? Should it be `VALV` for server data? | Check original GoldSrc behavior: if `JSAV+0x71` is correct, update baseline. |
| **`tokenCount` vs actual tokens written** | `StoreHashTable()` writes exactly `tokenCount`, but empty slots use 1-byte NUL. If `tokenCount = 5`, and only 3 are non-empty, does `tokenSize = 4 + 3 + 1 + 1 + 1 = 10`? Verify with fixture. | Write known tokens, compute expected size, compare to actual `tokenSize`. |
| **`pSaveData->time = 0.0f` reset** | Docs mention it preserves old-save compatibility; is this only for legacy saves (e.g., version < `0x71`) or always? Code applies unconditionally. | Add fixture: load pre-`0x71` save, verify time is zeroed before header read. |
| **Decal/landmark offset application** | Docs say “applied during restore”, but code only uses `LandmarkOrigin()` in `sv_restore.c`. Is it applied to decals/static entities? Unclear from `sv_save.c`. | Add fixture: save map with landmark, move player, verify decal positions shift correctly on restore. |

#### 🧪 **Suggested Fixture Tests**
1. **Malformed `.HL3`**: Write invalid index (e.g., `-1`, `tableCount+100`) and assert safe handling.
2. **Trailing token bytes**: Append 5 NULs after last token, verify parser doesn’t crash or misalign.
3. **Empty lightstyle count mismatch**: Set `lightStyleCount = 5`, write only 2 styles; ensure no read overflow.
4. **`viewentity` endianness test**: On non-x86 (if