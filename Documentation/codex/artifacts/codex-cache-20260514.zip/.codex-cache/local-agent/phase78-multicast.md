### Phase 78 Sidecar Audit: Xash3D `SV_Multicast` Routing Policy Extraction Boundaries

#### **1. Destination Modes**
- **`multicast_t` modes** (from `sv_client.h`, inferred from usage in `sv_world.c` and protocol):
  - `MULTICAST_ALL`: Send to all connected clients.
  - `MULTICAST_PVS`: Send only to clients within the entity’s PVS (based on leaf visibility).
  - `MULTICAST_ONE`: Send to a single client (`cl->edict` index specified).
  - `MULTICAST_ALL_R`: Reliable variant of `ALL`.
  - `MULTICAST_PVS_R`: Reliable variant of `PVS`.
- **Note**: Xash3D supports both reliable and unreliable variants via suffix `_R`. Unreliable is default unless `_R` is present.

#### **2. Visibility Mask Behavior**
- Uses `fatphs[]` (PVS/PHS cache) and `clientpvs[]` (per-client PVS).
- In `SV_Multicast`, visibility is computed via:
  - `SV_FatPVS()` → populates `fatphs[]`.
  - For each client, `SV_CullClientPVS()` or similar logic filters by:
    - Client’s current leaf.
    - Portal/room visibility (`sv.hostflags & SVF_MERGE_VISIBILITY`).
- **Key boundary**: Clients outside PVS are excluded unless message is `MULTICAST_ALL[_R]`.

#### **3. Reliable vs Unreliable Routing**
- **Unreliable**:
  - Appended to `sv.datagram`.
  - Subject to choking, rate limiting, and potential loss.
  - Used for high-frequency or non-critical data (e.g., `svc_temp_entity`).
- **Reliable** (`_R` variants):
  - Appended to `sv.reliable_datagram`.
  - Guaranteed delivery; retransmitted until acknowledged.
  - Limited by client’s `netchan.message.maxsize` and choked count.
- **Routing logic**: Determined at call site (e.g., `SV_Multicast(..., MULTICAST_PVS_R)` → writes to `reliable_datagram`).

#### **4. Spectator Proxy Behavior**
- Clients with `FCL_HLTV_PROXY` flag (`sv_client_t.flags`) are treated specially:
  - May receive messages even if outside PVS (if proxy is active).
  - Voice/data routing may bypass standard visibility checks.
  - In `SV_Multicast`, proxies are typically excluded from `PVS`-based routing unless explicitly included via game logic (e.g., `FL_PROXY` entity flag).
- **Boundary**: Spectators not in PVS of origin entity will *not* receive `MULTICAST_PVS[_R]`.

#### **5. Rewrite Behavior**
- Messages written to `sv.multicast` buffer are:
  - Preceded by `svc_multicast` header (contains routing flags + size).
  - Copied into per-client buffers only if client passes visibility/routing checks.
- **No in-place rewrite**: Buffer is immutable until flushed at frame end (`SV_FlushDatagram()`).
- **Overflow handling**:
  - If buffer exceeds `MAX_MULTICAST`, message is truncated or dropped (no explicit error log in `sv_game.c`).

#### **6. Useful Tests**
1. **PVS Culling**:
   - Spawn entity in room A; send `MULTICAST_PVS` from it.
   - Verify client in room B (non-portal-connected) receives nothing.

2. **Reliable vs Unreliable Delivery**:
   - Flood `sv.datagram` with unreliable messages, then send reliable test message.
   - Confirm reliable arrives at client while unreliable is dropped/choke-throttled.

3. **Spectator Proxy Routing**:
   - Connect HLTV proxy; spawn entity near active player.
   - Send `MULTICAST_PVS_R` from entity → verify proxy receives (if in same PVS) or not (if not).

4. **Visibility Mask Edge Cases**:
   - Test with `SVF_MERGE_VISIBILITY` enabled/disabled.
   - Verify portal camera entities (`FL_MERGE_VISIBILITY`) correctly merge PVS.

5. **Buffer Overflow**:
   - Send large multicast message (> `MAX_MULTICAST`).
   - Check if `bOverflow` flag is set in `sizebuf_t`, and whether client receives partial/corrupt data.

6. **Fakeclient Exclusion**:
   - Use `FCL_FAKECLIENT` (bot) to receive `MULTICAST_ALL`.
   - Confirm bots *do* receive unless message explicitly excludes them (rare).

---

**Uncertainty Flags**:  
- Exact `SV_Mult