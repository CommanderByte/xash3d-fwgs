### Advisory: Phase 71 Reslist Helper Boundary Review

#### ✅ **Strengths**
- Clean separation of concerns: `ReslistTokenProbe` (input validation/normalization) and `ReslistTokenDecision` (classification result).
- Sound prefix handling (`sound/`) is explicit, case-sensitive, and correctly falls back to generic when unsupported.
- Unsafe token rejection via `IsSafeDownloadName()` is well-tested in unit tests.

#### ⚠️ **Compatibility Risks**
1. **Missing `sound/` prefix validation in `SoundIndex` route**  
   - In `BuildReslistTokenDecision`, if `soundFormatSupported == true`, the code strips `kReslistSoundPrefix` (`"sound/"`) unconditionally—even if the normalized path doesn’t *actually* start with `"sound/"`.  
   - **Risk**: A malformed but safe token like `"soundx/foo.wav"` would be misrouted as sound, with `indexPath = "x/foo.wav"`, potentially causing client-side errors.  
   - **Fix**: Add a check: `probe.soundPathCandidate && StartsWith(probe.normalizedPath, kReslistSoundPrefix)` before stripping.

2. **No handling of trailing slashes or `"sound/"` alone**  
   - A token like `"sound/"` normalizes to `"sound/"`, passes `StartsWith`, and yields `indexPath = ""`. This may be invalid for precache APIs (`SV_SoundIndex("")`).  
   - **Fix**: Reject empty `indexPath`.

3. **No test for edge cases in `NormalizeSlashes`**  
   - Tests cover double-slash compaction but not leading/trailing slashes (e.g., `"/sound/foo.wav"` → `"sound/foo.wav"`? or `"//sound/foo.wav"`?).  
   - Legacy code (`COM_FixSlashes`) may expect different behavior—verify alignment.

#### 🔍 **Missing Tests**
- ❌ **`"sound/"` alone** (empty index path after stripping)  
- ❌ **Mixed-case prefix**: `"Sound/..."` should fall back to generic (covered), but what about `"sOuNd/..."`?  
- ❌ **Non-sound extension in sound-prefixed path with `soundFormatSupported=true`**, e.g., `"sound/foo.xyz"` → should be generic. *(Tested only for `false` case)*  
- ❌ **Path normalization edge cases**: `"sound\\\\foo.wav"`, `"sound/./foo.wav"`, `"sound/../foo.wav"` (latter two may pass `IsSafeDownloadName` but need correct behavior).  
- ❌ **Boundary: token exactly `"sound/" + extension`** (e.g., `"sound/.wav"`).

#### 📝 **Recommendations**
1. Add guard in `BuildReslistTokenDecision`:  
   ```cpp
   if (probe.soundPathCandidate && 
       StartsWith(probe.normalizedPath, kReslistSoundPrefix) &&
       soundFormatSupported)
   ```
2. Reject decision if `indexPath.empty()` after stripping.
3. Extend test suite with:
   - `"sound/"`, `"sound/.wav"`, `"sound/./foo.wav"`, `"sound/../foo.wav"`
   - Mixed-case prefix variants
   - Unsupported sound extension with `soundFormatSupported=true`
4. Confirm `IsSafeDownloadName` behavior for leading/trailing slashes aligns with legacy.

#### 🧪 **Suggested Test Snippet**
```cpp
static bool TestSoundPathEdgeCases()
{
    // Empty index path after stripping
    auto d1 = ClassifyReslistToken("sound/", true);
    if (d1.shouldIndex && !d1.indexPath.empty()) return false;

    // Unsupported format, supported flag → generic
    auto d2 = ClassifyReslistToken("sound/ambience/test.xyz", true);
    if (d2.type != ResourceType::Generic) return false;

    // Mixed case prefix → generic
    auto d3 = ClassifyReslistToken("sOuNd/weapons/pl_gun3.wav", true);
    if (d3.route == ReslistRoute::SoundIndex) return false;

    return true;
}
```

> **Summary**: Core logic is sound, but missing guards around `sound/` prefix stripping and insufficient edge-case tests pose