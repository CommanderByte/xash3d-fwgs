## Phase 75 Sidecar Audit: `svc_print` / `svc_stufftext` Extraction Boundaries

### Summary of Findings

- **No explicit length validation** is performed on text before writing to `svc_print`/`svc_stufftext`. All functions (`SV_ClientPrintf`, `SV_BroadcastPrintf`, `SV_BroadcastCommand`, and gamedll hooks like `pfnClientCommand`) rely on `Q_vsnprintf()` truncating to `MAX_SYSPATH` (256 bytes), but **no check is made against the actual message buffer capacity** during payload encoding.

- The text writing functions (`SV_WritePrintTextMessage`, `SV_WriteStuffTextMessage`, etc.) call `SV_TextMessage_Write*Payload()`, which likely writes bit-packed strings into a `sizebuf_t`. If the encoded string exceeds remaining bits, overflow occurs silently (only sets `msg->bOverflow = true`), but **no hard truncation or error handling is visible in the caller path**.

- In `sv_client.c`, `SV_WriteReconnectMessage()` uses `svc_stufftext` without payload validation — same risk.

### Compatibility Risks

| Function | Risk |
|---------|------|
| `SV_ClientPrintf` / `SV_BroadcastPrintf` (`svc_print`) | High: Long messages may overflow client-side print buffer (typically 256 bytes in GoldSrc). Client may crash or misparse subsequent packets. |
| `SV_BroadcastCommand` (`svc_stufftext`) | Critical: Stufftext is executed as console command on client; oversized strings can corrupt client’s command queue, cause crashes, or enable injection if untrusted input reaches here (e.g., via modded server commands). |
| `pfnClientCommand` (gamedll → server) | High: If gamedll passes arbitrarily long strings to `SV_BroadcastCommand`, it bypasses server-side limits. No client-side enforcement visible in provided code. |

### Suggested Tests

1. **Boundary Test**  
   - Send a `svc_print` message of exactly 256 bytes (null-terminated). Verify client displays full string and no truncation artifacts.
   - Repeat with 257+ bytes; confirm truncation occurs *before* network encoding, not after.

2. **Stufftext Overflow Test**  
   - Broadcast a `svc_stufftext` command of ~1024 characters (e.g., `"echo %s"` where `%s` is long string). Monitor client for crash or unexpected console spew.

3. **Buffer Overflow in Encoding**  
   - Use debug build with `sizebuf_t` instrumentation to verify `bOverflow` flag is set and no out-of-bounds writes occur when payload exceeds remaining bits (e.g., near end of reliable datagram).

4. **Gamedll Integration Test**  
   - In gamedll, call `pfnClientCommand()` with a 512-byte string. Verify server logs truncation or rejects it.

5. **Reconnect Message Edge Case**  
   - Trigger `SV_WriteReconnectMessage()` under high packet loss; verify reconnect command fits in single packet and doesn’t fragment into unreliable channel.

### Notes

- `MAX_SYSPATH = 256` is used for formatting, but `svc_print` protocol format uses `[byte] id [string] null terminated string`. If the *encoded* string (including null) exceeds remaining bits in `sizebuf_t`, overflow occurs.
- No evidence of `MSG_CheckOverflow()` or explicit bit-boundary checks before writing payloads — rely on internal `SV_TextMessage_Write*Payload()` to handle it. Confirm its implementation enforces safe bounds.

> **Recommendation**: Add explicit length clamping *before* encoding (e.g., limit print/stufftext payload to 200 bytes to allow for protocol overhead), and audit `SV_TextMessage_Write*Payload()` implementations for robustness.