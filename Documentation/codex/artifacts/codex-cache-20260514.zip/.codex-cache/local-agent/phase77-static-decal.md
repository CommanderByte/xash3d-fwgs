### Phase 77 Sidecar Audit: Xash3D Server Decal / Static Entity Message Extraction Boundaries  
*(Read-only analysis)*

---

#### **1. Compatibility-Sensitive Fields & Command Bytes**

| Field/Command | Source File(s) | Notes |
|---------------|----------------|-------|
| `svc_spawnstatic` (`20`) | `protocol.h`, `cl_parse.c` | Client expects full `entity_state_t` delta; `messagenum` field is **HACKHACK**-used to store model index (see `sv_save.c`). |
| `svc_bspdecal` (`36`) | `protocol.h`, `sv_game.c`, `ref_common.h` | Format: `[float*3][short][short][short]` → `(vec3_t pos, short entityIndex, short decalIndex, short flags)`. **Critical**: `entityIndex` is *signed short*, but may be `-1` for world. |
| `svc_resource` (`16`) | `sv_init.c`, `protocol.h` | Used for late precache of decals/models/sounds. Must match client-side resource list order. |

**⚠️ Critical Boundaries:**
- **Decal entityIndex**: Must be `< MAX_EDICTS` and valid (including `-1`).  
  → *No explicit bounds check in `sv_game.c` for decal creation; rely on caller validation.*
- **Static entity modelindex**: Stored in `messagenum`, but client reads it via `MSG_ReadDeltaEntity()` expecting a model index. Mismatched precache order breaks rendering.

---

#### **2. Command Byte Validation & Caller-Owned Checks**

| Function | File | Caller Responsibility |
|---------|------|------------------------|
| `SV_CreateDecal` | `sv_game.c` (not shown, but referenced) | Must validate: <br>• decal index `< MAX_DECALS` <br>• entityIndex ∈ `[-1, MAX_EDICTS)` <br>• position in world bounds |
| `SV_CreateStaticEntity` | `sv_game.c`, `sv_init.c` (indirect via `svc_spawnstatic`) | Must validate: <br>• modelindex is precached (`modelindex > 0 && modelindex < MAX_MODELS`) <br>• entity not exceeding `MAX_STATIC_ENTITIES` |
| `SV_SendSingleResource` | `sv_init.c` | Caller must ensure resource name is valid, index in range, and flags correct (e.g., `RES_FATALIFMISSING`). |

**⚠️ Missing Validation Risks:**
- No explicit bounds on decal count per map (`decalCount` in `SAVE_CLIENT` is unenforced at runtime).
- Static entity creation lacks overflow check before `clgame.numStatics++` (see `cl_parse.c`).

---

#### **3. Useful Tests for SV_CreateDecal / SV_CreateStaticEntity**

| Test | Purpose | Expected Behavior |
|------|---------|-------------------|
| **1. Decal with invalid entityIndex (`-2`, `MAX_EDICTS`)** | Boundary check | Server should drop or ignore; client must not crash. |
| **2. Static entity with unprecached model** | Model index validation | Client should log error, skip entity (or crash if strict). |
| **3. Decal + static ents during map restart (no save/restore)** | Restart idempotency | All decals/statics must be recreated cleanly; no stale references. |
| **4. Save/restore with > `MAX_DECALS` or `MAX_STATIC_ENTITIES`** | Serialization overflow | Server should truncate or error before write; client must not read past buffer. |
| **5. Late precache of decal/model during gameplay** | Resource sync | Client downloads and applies without desync; order matches server’s `sv.resources[]`. |

---

#### **4. Additional Notes**

- **`entity_state_t` packing**: Fields like `rendercolor`, `studio_state`, `controller`, etc., are tightly packed — ensure `MSG_ReadDeltaEntity()` matches server-side delta encoding.
- **Quake compatibility**: `svc_bspdecal` format differs between Quake/Half-Life; Xash3D uses Half-Life layout. Check `host.features &