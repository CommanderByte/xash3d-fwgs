### Phase 80 Sidecar Audit: Server Lifecycle Commands in `sv_cmds.c`

#### **Objective**
Identify *safe, target-neutral extraction boundaries* for the following commands:
```
map / map_background / load / save / autosave / restart / reload / changelevel / changelevel2
```
Constraints:
- Do **not** move `Cmd_Argv`, filesystem probes (e.g., `FS_Search`, `FS_FileExists`), cvars, or COM/SV execution logic.
- Preserve existing command parsing and validation.

---

### ✅ Safe Extraction Boundaries

| Command | Safe Boundary | Rationale |
|--------|----------------|-----------|
| **`map`** | `SV_Map_f()` → `COM_LoadLevel(mapname, false)` | Pure map load; no savegame interaction. `sv.background`, cvars, and filesystem checks are local to caller. Extraction safe if `COM_LoadLevel` is target-neutral (it is). |
| **`map_background`** | `SV_MapBackground_f()` → `COM_LoadLevel(mapname, true)` | Background map logic is self-contained; cvar latching (`maxplayers`, `deathmatch`) is local to this function. Safe boundary: before `COM_LoadLevel`. |
| **`load`** | `SV_Load_f()` → `SV_LoadGame(path)` | Savegame path construction is isolated. `SV_LoadGame()` handles file I/O and state reset internally. Extraction safe at `SV_LoadGame()` call site. |
| **`save` / `autosave`** | `SV_Save_f()` → `SV_SaveGame(...)` | Autosave (`quick save`) just wraps `save quick`. Save logic is self-contained in `SV_SaveGame()`. Safe boundary: before `SV_SaveGame()`. |
| **`restart`** | `Host_RestartGame_f()` (not shown, but implied) → `COM_LoadLevel(sv.name, false)` | If `sv.name` is preserved and no side effects on clients or state beyond reload, safe to extract at `COM_LoadLevel()` call. *Caution: verify no residual client cleanup.* |
| **`reload`** | Not implemented in `sv_cmds.c`. Likely alias of `restart`. Assume same as above. |
| **`changelevel` / `changelevel2`** | `SV_ChangeLevel_f()` / `SV_ChangeLevel2_f()` → `SV_SpawnServer(...)` or `COM_LoadLevel(newmap, false)` | These commands involve full server reset and client handoff. **Critical boundary**: *after* savegame archive (if any), but *before* `SV_SpawnServer` or `COM_LoadLevel`. Extraction safe if `sv.name`, `startspot`, and `sv.state = ss_dead` are preserved in caller context. |

> ⚠️ **Note**: `changelevel`/`changelevel2` may involve `savegame_comment` (see `sv_save.c`). Ensure no side effects on global state outside extraction scope.

---

### 🚨 Risks & Edge Cases

| Risk | Description |
|------|-------------|
| **1. Savegame comment hook (`pfnSaveGameComment`)** | In `sv_save.c`, this optional callback may be invoked during save/load (e.g., `SV_SaveGame()`). If extracted, ensure it’s either stubbed or target-neutral. |
| **2. Client state leakage** | Commands like `changelevel` reset client states (`cs_free`, `cs_zombie`). Extraction must preserve `svs.clients[i].state = cs_free` before new load. |
| **3. `sv.background` flag misuse** | `map_background` sets `background=true`. If extracted, ensure no other code assumes background state is false during map load. |
| **4. `sv_hostmap` cvar mutation** | `SV_Map_f()` calls `Cvar_DirectSet(&sv_hostmap, ...)`. Extraction must preserve this side effect or move it into caller. |
| **5. `COM_LoadLevel` assumptions** | It expects `sv.state == ss_dead`, clears world entities, etc. Ensure extraction doesn’t violate preconditions (e.g., leftover edicts). |

---

### ✅ Suggested Tests

1. **Unit-level (mocked)**  
   - Inject fake `Cmd_Argc()`/`Cmd_Argv()` → verify `mapname` is stripped of extension and validated via `SV_ValidateMap()`.  
   - Mock `COM_LoadLevel()` to assert it’s called with correct `(mapname, background)` flags.

2. **Integration (real server)**  
   - Run `map e1m1`, then `map e2m1` → verify no leftover entities or PVS corruption.  
   - `save quick` → `quickload` → verify state restoration fidelity.  
   - `changelevel e3m1` from `e1m1` → confirm client handoff (spectator → player) and savegame archive (if enabled).

3. **Target-neutral extraction test**  
   - Replace `COM_LoadLevel()` with a stub that logs args, then verify:
     - `map_background` always passes `background=true`.
     - `changelevel2` does *not* trigger autosave (unless explicitly requested).
     - `load`/`save` paths use correct `DEFAULT_SAVE_DIRECTORY`.

4. **Regression test**  
   - Run full Half-Life campaign in singleplayer with autosave enabled → verify no save corruption or missing comments.

---

### 🔍 Uncertainty Flags

| Item | Status |
|------|--------|
| `SV_ChangeLevel_f()` implementation | Not shown in `sv_cmds.c` — may reside in `sv_main.c