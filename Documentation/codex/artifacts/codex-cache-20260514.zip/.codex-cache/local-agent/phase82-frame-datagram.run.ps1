$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$request = Get-Content -LiteralPath 'C:\git\xash3d-fwgs\.codex-cache\local-agent\phase82-frame-datagram.request.json' -Raw | ConvertFrom-Json
$files = @()
foreach ($file in @($request.files)) {
    if (-not [string]::IsNullOrWhiteSpace($file)) {
        $files += [string]$file
    }
}

$params = @{
    PromptFile = [string]$request.promptFile
    Files = $files
    MaxFileChars = [int]$request.maxFileChars
    MaxTokens = [int]$request.maxTokens
    Temperature = [double]$request.temperature
    OutputPath = [string]$request.outputPath
}

if (-not [string]::IsNullOrWhiteSpace($request.baseUrl)) {
    $params.BaseUrl = [string]$request.baseUrl
}
if (-not [string]::IsNullOrWhiteSpace($request.model)) {
    $params.Model = [string]$request.model
}
if (-not [string]::IsNullOrWhiteSpace($request.apiKey)) {
    $params.ApiKey = [string]$request.apiKey
}

& 'C:\git\xash3d-fwgs\scripts\ask-local-model.ps1' @params