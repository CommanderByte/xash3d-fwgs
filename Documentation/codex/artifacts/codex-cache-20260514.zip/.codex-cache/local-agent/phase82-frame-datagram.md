### Phase 82 Side Audit Summary  
**Target Functions**: `SV_SendClientDatagram`, `SV_UpdateToReliableMessages`, `SV_SendClientMessages`  

---

#### ✅ **Safe Target-Neutral Helper Boundaries**

| Decision Point | Safe Boundary / Guard Condition | Rationale |
|----------------|----------------------------------|-----------|
| **Datagram Copy** (`cl->datagram` → main msg) | `MSG_GetNumBytesWritten(&cl->datagram) < MSG_GetNumBytesLeft(&msg)` | Prevents overflow of final datagram buffer. Overflow triggers warning, not crash. |
| **Fragmentation Decision** (reliable data → client netchan.message) | `MSG_GetNumBytesWritten(...) < MSG_GetNumBytesLeft(...)` | If false → `Netchan_CreateFragments()` invoked safely; no manual copy beyond limit. |
| **Ignore Reliable/Datagram on Overflow** | Explicit overflow check + warning (`Con_DPrintf`) before skipping write | Preserves legacy behavior: silent truncation is avoided, but not fatal. |
| **UserInfo Resend Gate** | `cl->next_sendinfotime <= host.realtime && MSG_GetNumBytesLeft(...) >= strlen(cl->userinfo) + 6` | Ensures buffer has *minimum* space; avoids partial writes. |
| **Movevars Resend Gate** | `FBitSet(cl->flags, FCL_RESEND_MOVEVARS)` → triggers full update unconditionally | No overflow check before write — relies on `netchan.message` having sufficient room (see below). |

---

#### 🛡️ **Overflow Clearing & Buffer Management**

| Buffer | Overflow Handling | Legacy Behavior Preserved? |
|--------|-------------------|----------------------------|
| `cl->datagram` | `MSG_Clear()` after copy or warning; no crash. | ✅ Yes — same as GoldSrc: overflow is non-fatal, only logged. |
| `sv.reliable_datagram`, `sv.datagram`, `sv.spec_datagram` | Cleared unconditionally at end of `SV_UpdateToReliableMessages`. | ✅ Yes — critical for preventing stale data in next frame. |
| `cl->netchan.message` (reliable) | Fragmentation fallback if insufficient space; no manual truncation. | ✅ Yes — fragments are reliable and standard-compliant. |

> ⚠️ **Note**: No explicit overflow check before writing to `cl->netchan.message` in `SV_UpdateToReliableMessages`. However, fragmentation handles it safely.

---

#### 🔁 **Resend Flags & Gates**

| Flag | Triggered By | Resent When | Gate Conditions |
|------|--------------|-------------|-----------------|
| `FCL_RESEND_USERINFO` | Userinfo change (`cl->userinfo_change_attempts > 0`) | After cooldown (`next_sendinfotime`) + buffer space check | `MSG_GetNumBytesLeft(...) >= strlen(cl->userinfo) + 6` |
| `FCL_RESEND_MOVEVARS` | Movevar change (e.g., gravity, friction) | Immediately on flag set | No overflow guard — relies on reliable channel capacity |

> ✅ **Legacy behavior preserved**: UserInfo is rate-limited (1.0s cooldown), and only resent if space permits.

---

#### 🚪 **Send-Loop Gates**

| Gate | Condition | Purpose |
|------|-----------|---------|
| `cl->state <= cs_zombie` | Skip zombies/fakeclients | Avoid sending to disconnected or invalid clients |
| `FBitSet(cl->flags, FCL_SKIP_NET_MESSAGE)` | Clear flag and skip | Allows one-frame message suppression (e.g., during changelevel) |
| `host_limitlocal.value && NET_IsLocalAddress(...)` | Localhost throttling | Prevents flooding on loopback unless explicitly disabled |
| `cl->state == cs_spawned` | Only send full frames to spawned clients | Ensures reliable data still sent, but entity updates only after spawn |

> ✅ **Legacy behavior preserved**: All gates match GoldSrc semantics (e.g., no entity updates before spawn).

---

#### 🧪 **Tests to Preserve Legacy Behavior**

| Test Scenario | Expected Behavior |
|---------------|-------------------|
| **Datagram overflow** | Warning logged, buffer cleared, message sent truncated. No crash. |
| **UserInfo change during cooldown** | Not resent until `next_sendinfotime` and buffer space available. |
| **Reliable msg too large for netchan.message** | Fragmentation occurs; no data loss. |
| **Client in `cs_connected` (not spawned)** | Receives reliable updates but *no* entity/event/ping data. |
| **Too many visible entities** | Entities beyond `MAX_VISIBLE_PACKET - 1` are silently ignored (`c_notsend++`). Warning logged once per overflow change. |

---

#### 📌 **Legacy Behavior Highlights**

- ✅ **No crash on buffer overflow** — only warnings and truncation.
- ✅ **Delta compression robustness**: Out-of-date delta frames trigger full update (no silent corruption).
- ✅ **PVS/PHS logic unchanged**: `EF_REQUEST_PHS`, `EF_MERGE_VISIBILITY` handled identically.
- ✅ **Entity overflow handling**: `c_notsend` counter tracks ignored entities; warning only if count changes.

---

#### ⚠️ **Uncertainty / Risk Flags**

| Area | Concern |
|------|---------|
| `SV_UpdateToReliableMessages()` → `sv.reliable_datagram` write to `netchan.message` | No explicit overflow guard *before* copy — relies on `MSG_GetNumBytesLeft(...)` check. If message buffer is corrupted or mis-sized, could overflow. |
| `