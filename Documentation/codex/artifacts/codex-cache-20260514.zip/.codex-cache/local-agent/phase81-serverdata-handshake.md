### Phase 81 Sidecar Audit: `SV_SendServerdata`, `SV_New_f`, `SV_Spawn_f`, `SV_Begin_f` in `sv_client.c`

#### Summary of Functions Analyzed

| Function | Role |
|---------|------|
| `SV_SendServerdata()` | Sends `svc_serverdata` to client; initializes signon sequence, spawncount, protocol version, etc. |
| `SV_New_f()` | Client command handler for `new` (initiates fresh spawn sequence). |
| `SV_Spawn_f()` | Handles `spawn` command — finalizes serverdata handshake before entering game. |
| `SV_Begin_f()` | Handles `begin` command — signals client readiness to receive full world state. |

---

### 🔍 Key Findings & Risk Assessment

#### 1. **Safe Target-Neutral Extraction Boundaries for Serverdata Payload Fields**
- `svc_serverdata` payload includes:
  - Protocol version (`int`)
  - Signon stage (`signonnum`, `byte`)
  - Spawncount (`int`)
  - Server flags (e.g., `SERVER_DEDICATED`, `sv.paused`)
  - Max clients, time, etc.

✅ **Safe extraction boundaries** exist for:
- `PROTOCOL_VERSION` → validated against client’s version in `SV_ConnectClient()`.
- `spawncount` → stored in `server_t.spawncount`, checked in `SV_Spawn_f()` and `SV_Begin_f()`.
- `signonnum` → strictly incremented (0→1→2→3), enforced by state machine (`cs_spawning`, `cs_spawned`).

⚠️ **Risks**:
- No explicit bounds check on `spawncount` before sending to client — if overflow occurs in `server_t.spawncount`, it may wrap and mismatch client expectations.
- `signonnum` is written as a raw byte (`MSG_WriteByte`) — no validation of range (should be 0–3). If corrupted, client may crash or hang.

**Suggested Test**:  
✅ Inject malformed `spawncount` values (>INT_MAX/2) and verify server doesn’t overflow.  
✅ Send `svc_signonnum` with value >3 to a client mid-handshake; observe if client crashes or ignores.

---

#### 2. **Developer Print Decision**
- `SV_SendServerdata()` uses `Con_DPrintf()` for debug prints (e.g., `"Serverdata sent\n"`).
- No sensitive data leakage in logs — only protocol info and state transitions.

✅ Safe for production use, but consider replacing with `Con_Reportf()` or conditional logging.

---

#### 3. **Spawncount Mismatch**
- In `SV_Spawn_f()`, client sends its local `spawncount` (`cl->state == cs_spawning`). Server compares it to `sv.spawncount`.
- If mismatch: client is dropped with `"spawn count mismatch\n"`.

⚠️ **Risk**:  
- No replay protection — if a client reconnects quickly, old spawncount may be reused before server increments.  
- However, `cs_zombie` timeout (`sv_timeout`) mitigates reuse window.

✅ Safe *if* `sv_timeout > 0`, but consider adding timestamp or nonce to prevent spawncount replay.

**Suggested Test**:  
✅ Simulate client reconnecting with stale `spawncount` (e.g., via packet replay). Verify server rejects it.  
✅ Bump `sv.spawncount` manually and verify mismatch is caught.

---

#### 4. **Signonnum & Resend Flags**
- `signonnum` is written as a byte in `svc_serverdata`, then client responds with `svc_signonnum`.
- Client may send `clc_delta` to request delta compression (bit 2 of `clc_stringcmd` flags).
- `FCL_RESEND_USERINFO`, `FCL_RESEND_MOVEVARS` flags are set on client connect/reconnect.

⚠️ **Risks**:
- No validation that `signonnum` is strictly increasing per session — if a client reuses old signon sequence (e.g., via packet replay), server may accept it.
- Resend flags (`FCL_RESEND_*`) are only checked in `SV_UpdateClientData()`; no enforcement of resend order.

✅ Mitigation: Signon sequence is tied to `cl->state`, and `cs_spawning` state prevents reuse until timeout.

**Suggested Test**:  
✅ Capture `svc_serverdata` + `svc_signonnum`, replay with same `signonnum`. Verify server rejects duplicate.  
✅ Send malformed delta request (`clc_delta`) without prior reliable message — check if client is dropped.

---

#### 5. **Overflow / Drop Behavior**
- Reliable buffer overflow handled via `netchan_t::message.bOverflow` flag.
- In `SV_SendServerdata()`, overflow is checked after each write:  
  ```c
  if( msg->bOverflow )
      return;
  ```
- Client is dropped on overflow only *after* message is attempted — but no explicit error log beyond `MSG_Write*()` internal warnings.

⚠️ **Risk**:  
- If reliable buffer overflows during `svc_serverdata`, client may receive incomplete data and hang/crash.
- No fallback (e.g., fragmentation or chunking) for large serverdata payloads.

✅ Safe *if* payload fits in `MAX_INIT_MSG` (16384 bytes), but no hard limit enforced on userinfo, model precache, etc.

**Suggested Test**:  
✅ Flood client with huge userinfo (e.g., 20k chars) → verify overflow is handled gracefully.  
✅ Force reliable